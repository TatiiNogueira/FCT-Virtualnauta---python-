#Módulos
from flask import Flask
from flask import render_template

#Iníciar o Flask e intoduzir a variável name, 
#Serve para confirmar que estou no arquivo principal
#E guardamos dentro de uma variável 
app = Flask(__name__, template_folder='.')

#Criar o URL e retornar um ficheiro 
@app.route('/')
def home():
    return render_template('home.html')

#Criar uma segunda página
@app.route('/python')
def about():
    return render_template('python.html')

#Verificar que estamos no arquivo inicial
if __name__ == '__main__':
    app.run(debug=True)